from .even import even_question
from .calc import calc_question

__all__ = ['even_question', 'calc_question']
