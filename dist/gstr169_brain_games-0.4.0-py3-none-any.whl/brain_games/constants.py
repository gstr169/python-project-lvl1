ANSWERS = {
    'no': False,
    'yes': True,
}

OPERATIONS = (
    ('+', int.__add__),
    ('-', int.__sub__),
    ('*', int.__mul__),
)
